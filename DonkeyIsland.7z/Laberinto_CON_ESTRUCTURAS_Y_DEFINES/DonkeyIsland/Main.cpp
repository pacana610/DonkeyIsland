#include <stdio.h>
#include <Windows.h>
#include "Objetos.hpp"
#include "Laberinto.hpp"

int salaActual;

void main()
{   
    salaActual = 0;
    
    IniciarObjetos();
    
    int opcion;
    
    system("cls");    

    while(!PoseeObjeto(3) || !PoseeObjeto(4) || !PoseeObjeto(5))
    {
        printf("--------------------\n");
        printf("      SALA %d\n", (salaActual + 1));
        printf("--------------------\n");
        printf("Salidas:\n");
        ListarSalidas(salaActual);
        printf("Puedes ver:\n");
        ListarObjetosEnSala(salaActual);
        printf("Posees:\n");
        ListarObjetosPoseidos();
        
        printf("Que quieres hacer?\n");
        
        printf("    1.- Ir a\n");        
        printf("    2.- Examinar objeto\n");
        printf("    3.- Recoger objeto\n");
        printf("    4.- Usar objeto\n");
        printf("Opcion? ");        
        scanf("%d", &opcion);
        
        if(opcion == 1)
        {
            printf("Salida? ");
            scanf("%d", &opcion);
            
            if(opcion == 1) { salaActual = ObtenSalaNorte(salaActual); }
            else if(opcion == 2) { salaActual = ObtenSalaSur(salaActual); }
            else if(opcion == 3) { salaActual = ObtenSalaEste(salaActual); }
            else if(opcion == 4) { salaActual = ObtenSalaOeste(salaActual); }
            
            Sleep(1000);
            
        }
        else if(opcion == 2)
        {
            printf("Objeto? ");
            scanf("%d", &opcion);
            
            ExaminarObjeto(opcion - 1);
            Sleep(2000);
            
        }
        else if(opcion == 3)
        {
            printf("Objeto? ");
            scanf("%d", &opcion);
            
            RecogerObjeto(opcion - 1);
            Sleep(2000);
            
        }
        else if(opcion == 4)
        {
            printf("Objeto? ");
            scanf("%d", &opcion);
            
            UsarObjeto(opcion - 1, salaActual);
            Sleep(2000);
        }        
        
        system("cls");
    }
    
    printf("Felicidades! Has recogido todos los tesoros de la cueva!");
}


