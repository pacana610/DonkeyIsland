#include <stdio.h>
#include <stdlib.h>
#include "Objetos.hpp"

Objeto objetos[NUM_OBJETOS];

void IniciarObjetos()
{
    // Mosca roja

    objetos[MOSCA_ROJA].sala = 3;
    objetos[MOSCA_ROJA].estado = ESTADO_NO_COMIDA;
    objetos[MOSCA_ROJA].recogido = 0;
    
    // Mosca verde
    
    objetos[MOSCA_VERDE].sala = 6;
    objetos[MOSCA_VERDE].estado = ESTADO_NO_COMIDA;
    objetos[MOSCA_VERDE].recogido = 0;

    // Mosca azul
    
    objetos[MOSCA_AZUL].sala = 1;
    objetos[MOSCA_AZUL].estado = ESTADO_NO_COMIDA;
    objetos[MOSCA_AZUL].recogido = 0;

    // Tesoro 1
    
    objetos[TESORO_1].sala = 2;
    objetos[TESORO_1].estado = 0;
    objetos[TESORO_1].recogido = 0;
    
    // Tesoro 2
    
    objetos[TESORO_2].sala = 4;
    objetos[TESORO_2].estado = 0;
    objetos[TESORO_2].recogido = 0;
    
    // Tesoro 3
    
    objetos[TESORO_3].sala = 9;
    objetos[TESORO_3].estado = 0;
    objetos[TESORO_3].recogido = 0;

    // Atrapamoscas
   
    objetos[ATRAPAMOSCAS].sala = 8;
    objetos[ATRAPAMOSCAS].estado = 0;
    objetos[ATRAPAMOSCAS].recogido = 0;

    // Nota
   
    objetos[NOTA].sala = 5;
    objetos[NOTA].estado = 0;
    objetos[NOTA].recogido = 0;
    
    // Explorador
    
    objetos[EXPLORADOR].sala = 5;
    objetos[EXPLORADOR].estado = 0;
    objetos[EXPLORADOR].recogido = 0;

    // Rana roja
    
    objetos[RANA_ROJA].sala = 4;
    objetos[RANA_ROJA].estado = ESTADO_NO_DISTRAIDA;
    objetos[RANA_ROJA].recogido = 0;
    
    // Rana verde
    
    objetos[RANA_VERDE].sala = 2;
    objetos[RANA_VERDE].estado = ESTADO_NO_DISTRAIDA;
    objetos[RANA_VERDE].recogido = 0;
    
    // Rana azul
    
    objetos[RANA_AZUL].sala = 9;
    objetos[RANA_AZUL].estado = ESTADO_NO_DISTRAIDA;
    objetos[RANA_AZUL].recogido = 0;
    

}

void ExaminarObjeto(int indice)
{
    if(indice == MOSCA_ROJA)
    {
        printf("Se mueve muy rapido para atraparla con las manos\n");
    }
    else if(indice == MOSCA_VERDE)
    {
        printf("Se mueve muy rapido para atraparla con las manos\n");
    }
    else if(indice == MOSCA_AZUL)
    {
        printf("Se mueve muy rapido para atraparla con las manos\n");
    }
    else if(indice == TESORO_1)
    {
        printf("Parece muy valioso\n");
    }
    else if(indice == TESORO_2)
    {
        printf("Parece muy valioso\n");
    }
    else if(indice == TESORO_3)
    {
        printf("Parece muy valioso\n");
    }
    else if(indice == ATRAPAMOSCAS)
    {
        printf("Es una red adecuada para cazar insectos\n");
    }
    else if(indice == NOTA)
    {
        printf("Pone que esta seguro que las ranas comen moscas, pero no de cualquier color\n");
    }
    else if(indice == EXPLORADOR)
    {
        printf("No tiene buen aspecto\n");
    }
    else if(indice == RANA_ROJA)
    {
        if(objetos[indice].estado == ESTADO_DISTRAIDA) { printf("Esta distraida comiendo"); }
        else { printf("Mejor no acercarse mucho a ella\n"); }
    }
    else if(indice == RANA_VERDE)
    {
        if(objetos[indice].estado == ESTADO_DISTRAIDA) { printf("Esta distraida comiendo"); }
        else { printf("Mejor no acercarse mucho a ella\n"); }
    }
    else if(indice == RANA_AZUL)
    {
        if(objetos[indice].estado == ESTADO_DISTRAIDA) { printf("Esta distraida comiendo"); }
        else { printf("Mejor no acercarse mucho a ella\n"); }
    }
}

void RecogerObjeto(int indice)
{
    if(indice == 0)
    {
        if(objetos[ATRAPAMOSCAS].recogido)
        {
            printf("Has atrapado la mosca con el atrapamoscas\n");
            objetos[MOSCA_ROJA].recogido = 1;
        }
        else
        {
            printf("La mosca se te escapo\n");
        }
    }
    else if(indice == 1)
    {
        if(objetos[ATRAPAMOSCAS].recogido)
        {
            printf("Has atrapado la mosca con el atrapamoscas\n");
            objetos[MOSCA_VERDE].recogido = 1;
        }
        else
        {
            printf("La mosca se te escapo\n");
        }
    }
    else if(indice == 2)
    {
        if(objetos[ATRAPAMOSCAS].recogido)
        {
            printf("Has atrapado la mosca con el atrapamoscas\n");
            objetos[MOSCA_AZUL].recogido = 1;
        }
        else
        {
            printf("La mosca se te escapo\n");
        }
    }    
    else if(indice == 3)
    {
        if(objetos[RANA_VERDE].estado == 1)
        {
            objetos[TESORO_1].recogido = 1;
            printf("Recoges el tesoro mientras la rana esta distraida comiendo\n");
        }
        else
        {
            printf("La rana intenta morderte.\n");
        }
    }
    else if(indice == 4)
    {
        if(objetos[RANA_ROJA].estado == 1)
        {
            objetos[TESORO_2].recogido = 1;
            printf("Recoges el tesoro mientras la rana esta distraida comiendo\n");
        }
        else
        {
            printf("La rana intenta morderte.\n");
        }
    }
    else if(indice == 5)
    {
        if(objetos[RANA_AZUL].estado == 1)
        {
            objetos[TESORO_3].recogido = 1;
            printf("Recoges el tesoro mientras la rana esta distraida comiendo\n");
        }
        else
        {
            printf("La rana intenta morderte.\n");
        }
    }
    else if(indice == 6)
    {
        objetos[ATRAPAMOSCAS].recogido = 1;
        printf("Recoges el atrapamoscas.\n");
    }    
    else if(indice == 7)
    {        
        objetos[NOTA].recogido = 1;
        printf("Recoges la nota.\n");
    }    
    else if(indice == 8)
    {        
        printf("Es demasiado asqueroso.\n");
    }    
    else if(indice == 9)
    {        
        printf("No se deja coger.\n");
    }    
    else if(indice == 10)
    {        
        printf("No se deja coger.\n");
    }    
    else if(indice == 11)
    {        
        printf("No se deja coger.\n");
    }    
        
}

int PoseeObjeto(int indice)
{
    return objetos[indice].recogido;
}

void UsarObjeto(int indice, int salaJugador)
{
    
    if(indice == MOSCA_ROJA)
    {
        if(salaJugador == objetos[RANA_AZUL].sala && objetos[RANA_AZUL].estado == 0)
        {
            objetos[RANA_AZUL].estado = 1;
            printf("La rana se come la mosca");
        }
        else
        {
            printf("No parece un buen sitio para liberar la mosca\n");
        }
    }
    else if(indice == MOSCA_VERDE)
    {
        if(salaJugador == objetos[RANA_ROJA].sala && objetos[RANA_ROJA].estado == 0)
        {
            objetos[RANA_ROJA].estado = 1;
            printf("La rana se come la mosca");
        }
        else
        {
            printf("No parece un buen sitio para liberar la mosca\n");
        }
    }
    else if(indice == MOSCA_AZUL)
    {
        if(salaJugador == objetos[RANA_VERDE].sala && objetos[RANA_VERDE].estado == 0)
        {
            objetos[RANA_VERDE].estado = 1;
            printf("La rana se come la mosca");
        }
        else
        {
            printf("No parece un buen sitio para liberar la mosca\n");
        }
    }
    else if(indice == 6)
    {
        int atrapada = 0;
        
        if(salaJugador == objetos[MOSCA_ROJA].sala && objetos[MOSCA_ROJA].estado == ESTADO_NO_COMIDA)
        {
            objetos[MOSCA_ROJA].recogido = 1;
            printf("Atrapas la mosca");

            atrapada = 1;
        }
        
        if(salaJugador == objetos[MOSCA_AZUL].sala && objetos[MOSCA_AZUL].estado == ESTADO_NO_COMIDA)
        {
            objetos[MOSCA_AZUL].recogido = 1;
            printf("Atrapas la mosca");

            atrapada = 1;
        }
        
        if(salaJugador == objetos[MOSCA_VERDE].sala && objetos[MOSCA_VERDE].estado == ESTADO_NO_COMIDA)
        {
            objetos[MOSCA_VERDE].recogido = 1;
            printf("Atrapas la mosca");

            atrapada = 1;            
        }
        
        if(!atrapada)
        {
            printf("No atrapas nada\n");
        }
    }
    else
    {
        printf("No puedes usar eso\n");
    }

}

void ListarObjetosPoseidos()
{
    if(objetos[MOSCA_ROJA].recogido) { printf("    1.- Mosca roja\n"); }
    if(objetos[MOSCA_VERDE].recogido) { printf("    2.- Mosca verde\n");  }
    if(objetos[MOSCA_AZUL].recogido) { printf("    3.- Mosca azul\n");  }
    if(objetos[TESORO_1].recogido) { printf("    4.- Tesoro\n");  }
    if(objetos[TESORO_2].recogido) { printf("    5.- Tesoro\n");  }
    if(objetos[TESORO_3].recogido) { printf("    6.- Tesoro\n");  }
    if(objetos[ATRAPAMOSCAS].recogido) { printf("    7.- Atrapamoscas\n");  }
    if(objetos[NOTA].recogido) { printf("    8.- Nota\n");  }
   
}

void ListarObjetosEnSala(int sala)
{
    if(objetos[MOSCA_ROJA].sala == sala && !objetos[MOSCA_ROJA].recogido) { printf("   1.- Mosca roja\n"); }
    if(objetos[MOSCA_VERDE].sala == sala && !objetos[MOSCA_VERDE].recogido) { printf("   2.- Mosca verde\n"); }
    if(objetos[MOSCA_AZUL].sala == sala && !objetos[MOSCA_AZUL].recogido) { printf("   3.- Mosca azul\n"); }
    if(objetos[TESORO_1].sala == sala && !objetos[TESORO_1].recogido) { printf("   4.- Tesoro\n"); }
    if(objetos[TESORO_2].sala == sala && !objetos[TESORO_2].recogido) { printf("   5.- Tesoro\n"); }
    if(objetos[TESORO_3].sala == sala && !objetos[TESORO_3].recogido) { printf("   6.- Tesoro\n"); }
    if(objetos[ATRAPAMOSCAS].sala == sala && !objetos[ATRAPAMOSCAS].recogido) { printf("   7.- Atrapamoscas\n"); }
    if(objetos[NOTA].sala == sala && !objetos[NOTA].recogido) { printf("   8.- Nota\n"); }
    if(objetos[EXPLORADOR].sala == sala) { printf("   9.- Esqueleto de un explorador\n"); }
    if(objetos[RANA_ROJA].sala == sala) { printf("   10.- Rana roja\n"); }
    if(objetos[RANA_VERDE].sala == sala) { printf("   11.- Rana verde\n"); }
    if(objetos[RANA_AZUL].sala == sala) { printf("   12.- Rana azul\n"); }
}



