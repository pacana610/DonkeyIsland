#ifndef _LABERINTO_HPP_
#define _LABERINTO_HPP_

#define NUM_SALAS 12

// Identificadores de direcciones

// 0 - Norte
// 1 - Sur
// 2 - Este
// 3 - Oeste

// Identificadores de salas

// 0 - Sala 1
// 1 - Sala 2
// 2 - Sala 3
// 3 - Sala 4
// 4 - Sala 5
// 5 - Sala 6
// 6 - Sala 7
// 7 - Sala 8
// 8 - Sala 9
// 10 - Sala 11


struct Sala
{
  int vecinaNorte;
  int vecinaSur;
  int vecinaEste;
  int vecinaOeste;  
};

int ObtenSalaNorte(int sala);
int ObtenSalaSur(int sala);
int ObtenSalaEste(int sala);
int ObtenSalaOeste(int sala);

void ListarSalidas(int sala);

#endif
