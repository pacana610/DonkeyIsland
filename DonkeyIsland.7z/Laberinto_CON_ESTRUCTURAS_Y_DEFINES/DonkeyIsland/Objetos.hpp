#ifndef _OBJETOS_HPP_
#define _OBJETOS_HPP_

#include "Laberinto.hpp"

#define NUM_OBJETOS 12

// Identificadores de los objetos

#define MOSCA_ROJA     0
#define MOSCA_VERDE    1
#define MOSCA_AZUL     2
#define TESORO_1       3
#define TESORO_2       4
#define TESORO_3       5
#define ATRAPAMOSCAS   6
#define NOTA           7
#define EXPLORADOR     8
#define RANA_ROJA      9
#define RANA_VERDE     10
#define RANA_AZUL      11


struct Objeto
{
    int sala;      // En que sala esta el objeto inicialmente
    int recogido;  // 1 si hemos recogido el objeto y 0 si no
    int estado;    // Estado del objeto. Se interpreta de forma diferente segun el tipo de objeto.
                   //       Para una mosca: 0 no se la ha comido una rana y 1 se la ha comido
                   //       Para una rana:  0 si no esta distraida y 1 si lo esta
};

#define ESTADO_NO_COMIDA 0
#define ESTADO_COMIDA 1

#define ESTADO_NO_DISTRAIDA 0
#define ESTADO_DISTRAIDA 1

void IniciarObjetos();
void RecogerObjeto(int indice);
void ExaminarObjeto(int indice);
void UsarObjeto(int indice, int sala);
int PoseeObjeto(int indice);
void ListarObjetosPoseidos();
void ListarObjetosEnSala(int sala);

#endif


